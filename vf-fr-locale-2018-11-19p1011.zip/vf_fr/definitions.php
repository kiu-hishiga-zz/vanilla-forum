<?php

 $LocaleInfo['vf_fr'] = array (
  'Locale' => 'fr',
  'Name' => 'Français / French',
  'EnName' => 'French',
  'Description' => 'Official French language translations for Vanilla. Help contribute to this translation by going to its translation site <a href="https://www.transifex.com/projects/p/vanilla/language/fr/">here</a>.',
  'Version' => '2018.11.19p1011',
  'Author' => 'Vanilla Community',
  'AuthorUrl' => 'https://www.transifex.com/projects/p/vanilla/language/fr/',
  'License' => 'CC BY-SA 4.0',
  'PercentComplete' => 96,
  'NumComplete' => 2333,
  'DenComplete' => 2425,
  'Icon' => 'fr.svg',
);
